import { type LazifyOptions, lazify } from "../plugins/lazify";
import { bindJQueryPlugin, hasJQuery } from "../utils/jquery-bridge";

(window as any).BlogrPlugins = Object.assign(
	(window as any).BlogrPlugins ?? {},
	{ lazify },
);

if (hasJQuery()) {
	bindJQueryPlugin(
		(window as any).jQuery,
		"lazify",
		(els, options?: LazifyOptions) => lazify(els, options),
	);
}

export type { LazifyOptions };

export { lazify };
